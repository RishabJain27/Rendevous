import android.app.TabActivity;

public class HobbyDetailTab extends TabActivity {
}
